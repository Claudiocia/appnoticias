package com.sinapse.unebnoticias.bancodados;

/**
 * Created by ClaudioSouza on 14/09/2016.
 */
public class NomeEcgu {
    private String nomeEcgu;
    private String siglaEcgu;
    private long idEcgu;

    public String getNomeEcgu() {
        return nomeEcgu;
    }

    public void setNomeEcgu(String nomeEcgu) {
        this.nomeEcgu = nomeEcgu;
    }

    public String getSiglaEcgu() {
        return siglaEcgu;
    }

    public void setSiglaEcgu(String siglaEcgu) {
        this.siglaEcgu = siglaEcgu;
    }

    public long getIdEcgu() {
        return idEcgu;
    }

    public void setIdEcgu(long idEcgu) {
        this.idEcgu = idEcgu;
    }
}
