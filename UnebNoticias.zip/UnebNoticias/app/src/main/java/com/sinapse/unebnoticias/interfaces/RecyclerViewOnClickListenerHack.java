package com.sinapse.unebnoticias.interfaces;

import android.view.View;

/**
 * Created by ClaudioSouza on 14/09/2016.
 */
public interface RecyclerViewOnClickListenerHack {
    public void onClickListener(View view, int position);
}
