package com.sinapse.unebnoticias.bancodados;

/**
 * Created by ClaudioSouza on 14/09/2016.
 */
public class TerrIdent {
    private int idTerrIdent;
    private String nomeTerrIdent;

    public int getIdTerrIdent() {
        return idTerrIdent;
    }

    public void setIdTerrIdent(int idTerrIdent) {
        this.idTerrIdent = idTerrIdent;
    }

    public String getNomeTerrIdent() {
        return nomeTerrIdent;
    }

    public void setNomeTerrIdent(String nomeTerrIdent) {
        this.nomeTerrIdent = nomeTerrIdent;
    }
}
