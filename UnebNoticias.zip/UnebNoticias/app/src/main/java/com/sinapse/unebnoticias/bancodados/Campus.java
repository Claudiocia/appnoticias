package com.sinapse.unebnoticias.bancodados;

/**
 * Created by ClaudioSouza on 14/09/2016.
 */
public class Campus {
    private String campusLoc;
    private String campusNum;
    private String campusNome;
    private String campusSigla;
    private String campusEnd;
    private String campusBairro;
    private String campusCep;
    private String campusCidade;
    private String campusUf;
    private int idCampus;

    public String getCampusLoc() {
        return campusLoc;
    }

    public void setCampusLoc(String campusLoc) {
        this.campusLoc = campusLoc;
    }

    public String getCampusNum() {
        return campusNum;
    }

    public void setCampusNum(String campusNum) {
        this.campusNum = campusNum;
    }

    public String getCampusNome() {
        return campusNome;
    }

    public void setCampusNome(String campusNome) {
        this.campusNome = campusNome;
    }

    public String getCampusSigla() {
        return campusSigla;
    }

    public void setCampusSigla(String campusSigla) {
        this.campusSigla = campusSigla;
    }

    public String getCampusEnd() {
        return campusEnd;
    }

    public void setCampusEnd(String campusEnd) {
        this.campusEnd = campusEnd;
    }

    public String getCampusBairro() {
        return campusBairro;
    }

    public void setCampusBairro(String campusBairro) {
        this.campusBairro = campusBairro;
    }

    public String getCampusCep() {
        return campusCep;
    }

    public void setCampusCep(String campusCep) {
        this.campusCep = campusCep;
    }

    public String getCampusCidade() {
        return campusCidade;
    }

    public void setCampusCidade(String campusCidade) {
        this.campusCidade = campusCidade;
    }

    public String getCampusUf() {
        return campusUf;
    }

    public void setCampusUf(String campusUf) {
        this.campusUf = campusUf;
    }

    public int getIdCampus() {
        return idCampus;
    }

    public void setIdCampus(int idCampus) {
        this.idCampus = idCampus;
    }
}
