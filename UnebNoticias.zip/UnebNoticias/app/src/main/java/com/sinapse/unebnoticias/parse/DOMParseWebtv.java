package com.sinapse.unebnoticias.parse;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.ArrayList;

/**
 * Created by ClaudioSouza on 14/09/2016.
 */
public class DOMParseWebtv {


    private RSSFeed _feed = new RSSFeed();

    public RSSFeed parseWebtv(String html) {


        try {
            //criando as instancias necessárias
            Document doc = Jsoup.connect(html).get();
            doc.normalise();

            ArrayList<Elements> listaElem = new ArrayList<Elements>();

            Elements novoDoc = doc.getElementsByClass("inside");
            int length2 = novoDoc.size();

            for (int i = 0; i < length2; i++) {
                listaElem.add(novoDoc.get(i).getElementsByClass("inside"));
            }

            int length = listaElem.size();

            for (int i = 0; i < length; i++) {

                RSSItem _item = new RSSItem();
                String imagem, titulo, link, img;

                titulo   = listaElem.get(i).select("h4").text().toString();
                _item.setTitle(titulo);

                link     = listaElem.get(i).select("a").attr("href").toString();
                _item.setLink(link);

                img      = listaElem.get(i).select("img").attr("src").toString();

                if( !img.isEmpty() ){
                    imagem = img;
                    _item.setImage(imagem);
                }
                else  {
                    imagem = "Sem imagem";
                    _item.setImage("");
                }

                // adiciona o item na lista
                _feed.addItem(_item);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

        return _feed;

    }
}
