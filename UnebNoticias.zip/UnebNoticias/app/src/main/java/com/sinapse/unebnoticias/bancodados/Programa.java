package com.sinapse.unebnoticias.bancodados;

/**
 * Created by ClaudioSouza on 14/09/2016.
 */
public class Programa {
    private int idProgram;
    private String programTit;
    private String programSigla;
    private String programResum;
    private String programDesc;
    private String programMptit;
    private String programUrlImg;
    private String programBenef;

    public int getIdProgram() {
        return idProgram;
    }

    public void setIdProgram(int idProgram) {
        this.idProgram = idProgram;
    }

    public String getProgramTit() {
        return programTit;
    }

    public void setProgramTit(String programTit) {
        this.programTit = programTit;
    }

    public String getProgramSigla() {
        return programSigla;
    }

    public void setProgramSigla(String programSigla) {
        this.programSigla = programSigla;
    }

    public String getProgramResum() {
        return programResum;
    }

    public void setProgramResum(String programResum) {
        this.programResum = programResum;
    }

    public String getProgramDesc() {
        return programDesc;
    }

    public void setProgramDesc(String programDesc) {
        this.programDesc = programDesc;
    }

    public String getProgramMptit() {
        return programMptit;
    }

    public void setProgramMptit(String programMptit) {
        this.programMptit = programMptit;
    }

    public String getProgramUrlImg() {
        return programUrlImg;
    }

    public void setProgramUrlImg(String programUrlImg) {
        this.programUrlImg = programUrlImg;
    }

    public String getProgramBenef() {
        return programBenef;
    }

    public void setProgramBenef(String programBenef) {
        this.programBenef = programBenef;
    }
}
